export const siemensPLC = [];
